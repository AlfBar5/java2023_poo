package interfaces;

public interface Operaciones {
	
	void girar(int grados);
	int invertir();
	

}
