package principal;

public class Test {

	public static void main(String[] args) {

		Punto3D pd= new Punto3D(3, 5, 6);
		pd.dibujar();
		
						
		//antes se ejecuta el código de la superclase
		// el método dibujar de la superclase lo hemos SOBREESCRITO
	}

}
