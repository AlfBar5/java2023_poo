package p1;

public class Uno {

	private int a;
	int b; //default
	protected int c;
	public int d;
	
}
