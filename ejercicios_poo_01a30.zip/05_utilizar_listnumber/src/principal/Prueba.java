package principal;

import service.ListNumber;

public class Prueba {

	public static void main(String[] args) {
		
		// Quiero usar la clase ArrayList extendida que usamos en el proyecto anterior
		ListNumber list=new ListNumber();

	}

}
